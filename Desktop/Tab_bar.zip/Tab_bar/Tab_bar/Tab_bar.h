//
//  Tab_bar.h
//  AutoChat
//
//  Created by Almas on 14.08.15.
//  Copyright (c) 2015 Ysmayl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Tab_bar : UITabBarController

@end
