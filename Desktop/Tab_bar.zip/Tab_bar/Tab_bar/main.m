//
//  main.m
//  Tab_bar
//
//  Created by Almas on 09.11.15.
//  Copyright © 2015 None. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
