//
//  chat.m
//  Tab_bar
//
//  Created by Almas on 09.11.15.
//  Copyright © 2015 None. All rights reserved.
//

#import "chat.h"
#import "Tab_bar.h"
@interface chat ()

@end

@implementation chat

- (void)viewDidLoad {
    UIImage * selectedImage = [UIImage imageNamed:@"zakaz_b"];
    UIImage * unselectedImage = [UIImage imageNamed:@"zakaz_y"];
    Tab_bar *tab = [[Tab_bar alloc] init];
    UITabBarItem * item = ((UITabBarController*)([tab.viewControllers objectAtIndex:0])).tabBarItem;
    
    [item setImage:unselectedImage];
    [item setSelectedImage:selectedImage];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
