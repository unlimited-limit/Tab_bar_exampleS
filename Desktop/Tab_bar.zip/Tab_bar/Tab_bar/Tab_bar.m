//
//  Tab_bar.m
//  AutoChat
//
//  Created by Almas on 14.08.15.
//  Copyright (c) 2015 Ysmayl. All rights reserved.
//

#import "Tab_bar.h"

@implementation Tab_bar


- (void)viewDidLoad {
    [super viewDidLoad];


  
    UITabBarItem *item0 = [self.tabBar.items objectAtIndex:0];
        item0.image = [[UIImage imageNamed:@"lenta_y"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        item0.selectedImage = [UIImage imageNamed:@"lenta_b"];
        item0.title=@"Лента";
    



    
    UITabBarItem *item1= [self.tabBar.items objectAtIndex:1];
    item1.image = [[UIImage imageNamed:@"chan_y"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    item1.selectedImage = [UIImage imageNamed:@"chat_b"];
    
    UITabBarItem *item2= [self.tabBar.items objectAtIndex:2];
    item2.image = [[UIImage imageNamed:@"profile_y"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    item2.selectedImage = [UIImage imageNamed:@"profile_b"];



    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
 -(void)viewWillAppear:(BOOL)animated{ [super viewWillAppear:animated]; self.tabBarController.navigationItem.hidesBackButton=YES;
     [self.navigationController setNavigationBarHidden:YES animated:animated];
     [super viewWillAppear:animated];
 
 }

@end
